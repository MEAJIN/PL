public class lex {
	public static int token;
	static char ch = 0;
	static char ident;
	static char intValue;
	public static String Result;
	//��ū
	public static int getToken() {	
		ch = Buf.get();
		//Buf.index = 0;
		
		//���� ������ ���
		while(Character.isWhitespace(ch)) { 
			ch = Buf.get();
			//System.out.println(ch);
		}
		
		while(ch != 0) {
			//������ ��� 
			if(Character.isLetter(ch)) {
				System.out.print(ch); //���
				ident = ch; 
				ch = Buf.get();
				//System.out.println(ch);
				token = Token.var; //���� ��ū�ΰ� �˷���
			}
			
			//������ ���
			else if(Character.isDigit(ch)) {
				System.out.print(ch);
				intValue = ch;
				ch = Buf.get();
				//System.out.println(ch);
				token = Token.num;
			}
			//�� ���� ���
			else {
				//System.out.print(ch);				
				switch(ch) {
					case ';': //';'�� ���
						ch = Buf.get(); //���ۿ��� ��ū�� �����´�
						token = Token.semicolon; //
						break;	
						
					case '[':
						ch = Buf.get();
						token = Token.ll_paren;
						break;
						
					case ']':
						ch = Buf.get();
						token = Token.rl_paren;
						break;
						
					case '=':
						ch = Buf.get();
						token = Token.assign;
						break;
						
					case'{':
						ch = Buf.get();
						token = Token.lc_paren;
						break;	
						
					case '}':
						ch = Buf.get();
						token = Token.rc_paren;
						break;	
						
					case'(':
						ch = Buf.get();
						token = Token.lp_code;
						break;	
						
					case ')':
						ch = Buf.get();
						token = Token.rp_code;
						break;	
						
					case ',':
						ch = Buf.get();
						token = Token.comma;
						break;
						
					case '.':
						ch = Buf.get();
						token = Token.period;
						break;	
						
					case '+':
						ch = Buf.get();
						token = Token.add;
						break;
						
					case '-':
						ch = Buf.get();
						token = Token.sub;
						break;
						
					case 'x':
						ch = Buf.get();
						token = Token.multi;
						break;
						
					case '%':
						ch = Buf.get();
						token = Token.div;
						break;	
						
					case '^':
						ch = Buf.get();
						token = Token.power;
						break;	
						
					case '#':
						ch = Buf.get();
						token = Token.Array;
						break;	
						
					case '~':
						ch = Buf.get();
						token = Token.LinkedList;
						break;	
						
					//��� �ƴ� ��� 
					default:
						error("Lexer:"+ ch + "��(��) �ùٸ� ��ū�� �ƴմϴ�.");
						break;			
				}
				Result = Token.toString(token);
				System.out.print(Result);
			}		
			//return token; //��ū ���� ��ȯ
		}
		return token;
	}

	public static String letter() {
		String letter = null;
		letter = letter + Buf.get(); 
		System.out.println("letter : " + letter);
		return letter;
	}

	public static void error(String string) {
		System.out.println("\nError");
		System.out.println(string);
	}
}