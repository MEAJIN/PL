public class Token {
	public static final int semicolon = 0; 	// ';'
	public static final int ll_paren = 1; 	// '['
	public static final int rl_paren = 2; 	// ']'
	public static final int assign = 3; 	// '='
	public static final int lc_paren = 4; 	// '{'
	public static final int rc_paren = 5; 	// '}'
	public static final int lp_code = 6;	// '('
	public static final int rp_code = 7;	// ')'
	public static final int comma = 8; 		// ','
	public static final int period = 9; 	// '.'
	public static final int add = 10; 		//'+'
	public static final int sub = 11; 		//'-'
	public static final int multi = 12; 	//'x'
	public static final int div = 13; 		//'%'
	public static final int power = 14; 	// '^'
	public static final int Array = 15; 	// '#'
	public static final int LinkedList = 16;// '~'
	public static final int var = 17; 		// '����'
	public static final int num = 18; 		// '����'

	private static String[] spell = {
			";", "[", "]", "=", "{", "}", "(", ")",
			",", ".", "+", "-",  "x", "%", "^", "Array ", "LinkedList ",
			"var", "num"};
	
	public static String toString(int saveToken) {
		if(saveToken < 0 || saveToken > num)
			return "";
		return spell[saveToken];
	}
}