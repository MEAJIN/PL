
public class Buf {
	static char[] array_word;
	static String input; 
	static int index = 0;
	
	public Buf(String s) {
		array_word = new char[s.length()];
		//System.out.println("Buf");

		for(int i = 0; i < s.length(); i++) {
			array_word[i] = s.charAt(i);
			//System.out.print(array_word[i]);
		}
	}
	
	public static char get() {		
		//System.out.println("\n\nindex : " + index);
		if(index < array_word.length) {
			return array_word[index++];
		}
		return 0;
	}
}