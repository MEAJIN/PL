import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class Draw extends JFrame {
	 private static JTextArea text_area;
	
	String s, tmp;
	int endpos;

	private JLabel label;
	
	public Draw() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(300,200);
		
		
		
		add(label);
		setVisible(true);
	}
	
	public void LinkedList() {
		s = lex.Result;		
		
		if(s.startsWith("LinkedList")) {
			tmp = s.substring(10); //10��° �ε��� ���� �ڸ���
			endpos = tmp.indexOf("[");
			tmp = tmp.substring(0,endpos);
			label = new JLabel("LinkedList SIZE : " + tmp); 
		}
	}
	
	@Override
	public void paint(Graphics g) {
		int x = 20;
		super.paint(g);
		for(int i = 0; i < Integer.parseInt(tmp); i++) {
			g.drawRect(x + 10, 20, 10, 20);
		}
	}
}
