import java.util.Scanner;

public class Term {
	public static void main(String[] args) throws Exception {
		String message;
		Scanner scan = new Scanner(System.in);
		
		message = scan.nextLine();
		Buf buf = new Buf(message);
		
		Draw d = new Draw();

		Paser paser = new Paser();
		paser.program();
	}
}
