
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class lexer {
   int charclass;

   char nextchar;
   char[] arr;
   int lexlen=0;
   int token;
   int fchar;
   int nextToken;
   Scanner sc;
   FileReader in_fp;
   FileReader fopen;
   
   //���� ����
   final static int LETTER =0;
   final static int DIGIT =1;
   final static int UNKNOWN =99;
   final static int EOF=77;
   
   //��ū �ڵ�
   final static int INT_LIT =10;
   final static int IDENT =11;
   final static int ASSIGN_OP =20;
   final static int ADD_OP =21;
   final static int SUB_OP =22;
   final static int MULT_OP =23;
   final static int DIV_OP=24;
   final static int POW_OP=25;   
   final static int LEFT_PAREN =25;
   final static int RIGHT_PAREN =26;
   
   public lexer() throws Exception {
      fopen=new FileReader("sample.txt");
      sc=new Scanner(fopen);
      getchar();
      do {
         lex();
      }while(fchar!=-1);
   }
   void addchar() {
      if(lexlen<=98) {
         arr[lexlen++]=nextchar;
      }
      else
         System.out.println("����");
   }
   void getchar() throws IOException {
      if((fchar=fopen.read())!=-1){
         nextchar=(char)fchar;
         if((nextchar >='A' && nextchar <= 'Z') || (nextchar >= 'a' && nextchar <= 'z')) {
            charclass=LETTER;
         }
         else if(nextchar>=48&&nextchar<=57) {
            charclass=DIGIT;
         }
         else {
            charclass=UNKNOWN;
         }
      }
      else
         charclass=EOF;
      
   }

   int lookup(char ch) {
      switch(ch){
	      case '(':
	         addchar();
	         nextToken=LEFT_PAREN;
	         break;
	      case ')':
	         addchar();
	         nextToken=RIGHT_PAREN;
	         break;
	      case '+':
	         addchar();
	         nextToken=ADD_OP;
	         break;
	      case '-':
	         addchar();
	         nextToken=SUB_OP;
	         break;
	      case '*':
	         addchar();
	         nextToken=MULT_OP;
	         break;
	      case '/':
	         addchar();
	         nextToken=DIV_OP;
	         break;
	         
	      case '^':
	          addchar();
	          nextToken=POW_OP;
	          break;
	          
	      default:
	         addchar();
	         nextToken=EOF;
	         break;
	      }
      return nextToken;
   }
   
   int lex() throws Exception {
      lexlen=0;   
      arr=new char[100];
      switch(charclass) {
      
      case LETTER:
         addchar();
         getchar();
         while(charclass==LETTER||charclass==DIGIT) {
            addchar();
            getchar();
         }
         nextToken=IDENT;
         break;
         
      case DIGIT:
         addchar();
         getchar();
         while(charclass == DIGIT) {
            addchar();
            getchar();
         }
         nextToken=INT_LIT;
         break;
         
      case UNKNOWN:
         lookup(nextchar);
         getchar();
         break;
         
      case EOF:
         nextToken=EOF;
         break;
      }
      
      String ctos=String.valueOf(arr);
      System.out.println("next token : "+ctos);
      return nextToken;
   }
   
   public static void main(String[] args) throws Exception{
      lexer lex = new lexer();
   }
}