
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Lexer {
	FileReader in_fp;
	static FileReader FileOpen;
	Scanner sc;
	static int in;
	
	static int charClass;
	static char ch;
	static char[] arr;
	static int lexLen=0;
	static int nextToken;
	int token;
	  
	static String lexeme;
	String nt;

	static String line = null;
	static ArrayList<String> tmpList; //�迭�� ���Ұ� ����
	Map<String, ArrayList> h; //�迭�� �̸��� ���� ����Ʈ ����
	
	public Lexer() {
		tmpList = new ArrayList<String>();
		h = new HashMap<String, ArrayList>();
		
		try {
			FileOpen = new FileReader("sample.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		sc = new Scanner(FileOpen);
		getchar();
	     /*
		do {
			lex();
		}while(in != -1);*/
	}
	   
	static void addchar() {
		if(lexLen <= 98) {
			arr[lexLen++] = ch;
		}
		else
			System.out.println(" Eror : Inedex Out Of Range");
	}
	   
	static void getchar() {
		try {
			if((in = FileOpen.read()) != -1){
				ch = (char)in;
			     
				if(Character.isLetter(ch)) { //���ڸ�
					charClass = Token.LETTER; 
				}
			     
				else if(Character.isDigit(ch)) { //������
					charClass = Token.DIGIT;
				}
			     
				else { //�� �� ��ȣ�� ������ 
					charClass = Token.UNKNOWN;
				}
			}
			else
				charClass = Token.EOF;
			
		} catch (IOException e) {
			e.printStackTrace();
		}    
	}
	
	static int lookup(char ch) {
		switch(ch){
		
			case '(':
				addchar();
				nextToken = Token.LEFT_PAREN;
				break;
				
			case ')':
				addchar();
				nextToken = Token.RIGHT_PAREN;
				break;
				
			case '{':
				addchar();
				nextToken = Token.LC_PAREN;
				break;
				
			case '}':
				addchar();
				nextToken = Token.RC_PAREN;
				break;
				
			case '[':
				addchar();
				nextToken = Token.LL_PAREN;
				break;
				
			case ']':
				addchar();
				nextToken = Token.RL_PAREN;
				break;
				
			case ',':
				addchar();
				nextToken = Token.DOT;
				break;
 				
			case '=':
				addchar();
				nextToken = Token.ASSIGN_OP;
				break;
									
			case '+':
				addchar();
				nextToken = Token.ADD_OP;
				break;
 				
			case '-':
				addchar();
				nextToken = Token.SUB_OP;
				break;
				
			case '*':
				addchar();
				nextToken = Token.MULT_OP;
				break;
				
			case '/':
				addchar();
				nextToken = Token.DIV_OP;
				break;
			
			case ';':
				addchar();
				nextToken = Token.SEMICOLON;
				break;
				
			default:
				addchar();
				nextToken = Token.EOF;
				break;
			}
		
		return nextToken;
	}	
	   
	static int lex() {
		lexLen = 0;   
		arr = new char[100];
		
		switch(charClass) {	      
			case Token.LETTER:
				addchar();
				getchar();
				while(charClass == Token.LETTER || charClass == Token.DIGIT) {
					addchar();
					getchar();
				}
				nextToken = Token.IDENT;
				break;
	         
			case Token.DIGIT:
				addchar();
				getchar();
				while(charClass == Token.DIGIT) {
					addchar();
					getchar();
				}
				nextToken = Token.INT_LIT;
				//tmpList.add(lexeme);
				break;
	         
			case Token.UNKNOWN:
				lookup(ch);
				getchar();
				break;
	         
			case Token.EOF:
				nextToken = Token.EOF;
				break;
			}
	      
		lexeme = String.valueOf(arr);
		tmpList.add(lexeme);
		//createArray();
		System.out.println("Next token : " + nextToken + " Next lexeme : " + lexeme);		
		return nextToken;
	}
	   
	public static void Error(String string) {
		System.out.println("\nError");
		System.out.println(string);
	}
	 
	//����ڰ� �Է��� �迭�� HashMap�� ����
	//������ ���ڿ��� ���� �� ,  
	public static void createArray() {
		//tmpList.forEach(System.out::print);
		int size, endpos, startpos;
		String start;
		String s = null, tmp, id1, id2;
		for(int i = 0; i < tmpList.size(); i++) {
			tmpList.set(i,tmpList.get(i).trim());
			System.out.print(tmpList.get(i));
			s += tmpList.get(i); //�ϳ��� ���ڿ��� ����
		}
		tmp = s;
		
		String[] expr = tmp.split(";");
		System.out.println(" ");
		
		String tmp_expr1 = expr[0];
		String tmp_expr2 = expr[1];
		
		//ù��° ���̵� ���ϱ�
		start = tmp_expr1.substring(4);
		endpos = start.indexOf("[");
		
		id1 = start.substring(0,endpos);
		System.out.println("id1 : " + id1);		
		
		//�ι�° ���̵� ���ϱ�
		endpos = tmp_expr2.indexOf("[");		
		id2 = tmp_expr2.substring(0,endpos);
		System.out.println("id1 : " + id2);	
	
		System.out.println("expr1 : " + start);
		System.out.println("expr2 : " + tmp_expr2);
		
		for(int i = 0; i < start.length(); i++) {
			if(start.contains("{")) {
				startpos = start.indexOf("{");
				endpos = start.indexOf("}");
				start.substring(startpos, endpos);				
			}
			if(tmp_expr2.contains("{")) {
				startpos = tmp_expr2.indexOf("{");
				endpos = tmp_expr2.indexOf("}");
				tmp_expr2.substring(startpos, endpos);				
			}
		}
		
		String[] num_list = start.split(",");
		for(String ss : num_list) {
			//System.out.println(ss);
		}
		ArrayList<Integer> num = new ArrayList<>();
	
	}
	
	public static void main(String[] args) throws Exception{
		System.out.print(System.getProperty("user.dir"));
		Lexer lex = new Lexer();
		Parser parser = new Parser();
		parser.program();
		createArray();
	}
}