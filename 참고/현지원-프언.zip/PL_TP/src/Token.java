public class Token {
	//���� ����
	public final static int LETTER =0;			//����
	public final static int DIGIT =1;			//����
	public final static int UNKNOWN =2;		//��ȣ�� ������
	public final static int EOF=3;
	   
	//��ū �ڵ�
	public final static int INT_LIT =4;			//����
	
	public final static int IDENT =5;			//���̵�
	public final static int DOT =6;				//','
	
	public final static int ASSIGN_OP =7;		//'='
	public final static int ADD_OP =8;			//'+'
	public final static int SUB_OP =9;			//'-'
	public final static int MULT_OP =10;		//'*'
	public final static int DIV_OP=11;			//'/'
	public static final int SEMICOLON = 12; 	// ';'

	public final static int LEFT_PAREN =13; 	//'('
	public final static int RIGHT_PAREN =14;	//')'
	public static final int LC_PAREN = 15; 		// '{'
	public static final int RC_PAREN = 16; 		// '}'
	public static final int LL_PAREN = 17; 		// '['
	public static final int RL_PAREN = 18; 		// ']'
	
	private static String[] list = {
			" LETTER ", " DIGIT ", " UNKNOWN ", " EOF "," INT_LIT ", " ID ", 
			" , ", " = ", " + ", " - ",  " * ", " / ", " ; ", " ( ", " ) ", 
			" { ", " } ", " [ ", " ] ",};

	public static String toString(int saveToken) {
		if(saveToken < 0 || saveToken > RL_PAREN)
			return "";
		return list[saveToken];
	}
}

