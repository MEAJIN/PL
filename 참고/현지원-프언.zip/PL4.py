a = "a : main \n"
b = "b : main \n"
c = "c : main \n"

def fun1():
    b = "b : fun1 \n"
    c = "c : fun1 \n"
    d = "d : fun1 \n" 
    print ("fun1 :\n", a  + b + c + d)
    
    def fun2():
        global a
        a = "a : main(global) \n"
        c = "c : fun2 \n"
        d = "d : fun2 \n"
        e = "e : fun2 \n"          
        print ("fun2 :\n", a + b + c + d + e)
        
        def fun3():
            nonlocal e
            d = "d : fun3 \n"
            e = "e : fun3(nonlocal) \n"
            f = "f : fun3 \n"
            print ("fun3 :\n", a + b + c + d + e + f)
            
        print("\nfun3 호출:")
        fun3()
    print("\nfun2 호출:")
    fun2()

print("\nfun1 호출:")
fun1()

     
